#!/usr/bin/python

import sys
import math

# NOTE: this script assumes that alpha is large (>5)
# for small alpha, the results are not guaranteed to
# be accurate

if(len(sys.argv) < 2):
    print 'usage: python', sys.argv[0], '<s>'
    exit()

s = float(sys.argv[1])

pfix = 0
if (s >= 0.1):
    pfix = math.exp(-(1+s))
    lim = 0
    while(lim < 100):
       pfix = math.exp((1+s)*(pfix-1))
       lim +=1
    pfix = 1-pfix
else:
    pfix = (1-math.exp(-2*s))

print pfix

