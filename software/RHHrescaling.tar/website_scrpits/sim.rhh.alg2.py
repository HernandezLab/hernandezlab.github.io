#!/usr/bin/python

import sys
import string
import os
import random
import math
from os.path import exists
from scipy.integrate import *
import mpmath
from scipy.optimize import *

# check input

if len(sys.argv) < 2:
    print 'usage: python', sys.argv[0] ,'<argument>'
    print 'arguments:'
    print '--return_params'
    print '--build_sfs_code'
    exit()

alpha = 5*10**3    # population scaled selection coefficient
delta_I = 0.02     # constraint on the value of I_{alpha,s} (see the paper!)  
N0 = 5*10**3       # Size of the population we want to model
r0 = (5.*10**-8)   # recombination rate in the population of size N0, per generation per chromosome per base pair
lam0 = (10**-10)   # rate of positively selected substitutions
L0 = 1.*10**6      # Flanking length in the population of size N0
s0 = alpha/(2.*N0) # strength of selection in the model population
tol = 0.000001     # just a small number to keep the numerical optimization from running forever

a =  s0/(r0*L0)    # dummy variable that calculates the ratio of s/rL, which is conserved
                   # under the rescaling

min_pop = 200      # This is the minimum population size.  Note, the calculation
                   # of mpmath.gamminc can become unstable when min_pop is small
                   # and/or alpha is very large.  You can increase min_pop in this
                   # case to avoid the error messages and get a result

delta_p = 0.05     # constraint on p_{\tau_f}, which is the probability of identity
                   # at the end of a sweep (see the paper!)

L_flank = 10**5    # flanking sequence length, can be more or less as small as we desire,
                   # up to the point where the approximation of recombination as a continuous 
                   # in space process breaks down

r_lam_ratio = r0/lam0  # this ratio is conserved under the rescaling

# the below function calculates p_{\tau_f} for a given value of (u,s), where u = 2rL/s

def high_s(u,s):
    return math.exp(-2*(1-math.exp(-s*u)))*(1 - ((1-math.exp(-s*u))/s)*(alpha**(-(1-math.exp(-s*u))/s))*mpmath.gammainc(-(1-math.exp(-s*u))/s,1/(alpha+0.)))

# integ(s) calculates the value of I_{\alpha,s} (see the paper!)

def integ(s):
    u_max = 2/a
    
    SWL = lambda u: math.exp(-2*(1-math.exp(-s*u)))*(1 - ((1-math.exp(-s*u))/s)*(alpha**(-(1-math.exp(-s*u))/s))*mpmath.gammainc(-(1-math.exp(-s*u))/s,1/(alpha+0.)))

    return r_lam_ratio/(r_lam_ratio + alpha*quad(SWL,0,u_max)[0])

# init is the value of I_{\alpha,s} in the population of size N0

init = integ(s0)

# optim(s) is the optimization function, of which we want to find a root. It
# calculates the difference between I_{\alpha,s} and init, relative to init

def optim(s):
    return (integ(s)-init)/init-delta_I

# the maximum value of s we are willing to accept, as determined by our min_pop

s = alpha/(2.*min_pop)

# find root below

try:
    s = brentq(optim,s0,s)
except ValueError:
    s = alpha/(2.*min_pop)

# Next, we check if we have already satisifed the delta_p constraint
# We are using brute here because the fancier optimization algorithms in
# SciPy all wander off into weird parameter space sometimes

test = brute(lambda u: -(math.fabs(high_s(u,s) - high_s(u,s0))),ranges=[(0.,2/a)])

diff = math.fabs(high_s(test[0],s) - high_s(test[0],s0))

# If we haven't satisfied delta_p, keep ratcheting up N to find the solution
# for this constraint 

if (diff > delta_p):
    s1 = s
    while( diff >= delta_p + tol):
        def optim2(s):
           return math.fabs(high_s(test[0],s) - high_s(test[0],s0)) - delta_p
        s = brentq(optim2,s0,s)
        test = brute(lambda u: -(math.fabs(high_s(u,s) - high_s(u,s0))),ranges=[(0.,2/a)])
        diff = math.fabs(high_s(test[0],s) - high_s(test[0],s0))
  
r = s/(a*L_flank)
lam = r*lam0/r0
N = int(alpha/(2*s))
theta_des = 0.002
L_mid = 1000.0
rho = r*4*N

if(sys.argv[1] == '--return_params'):

    print 'N: ', N
    print 'L: ', L_flank
    print 'alpha: ', alpha
    print 'rho :', rho
    print 'lambda: ', lam
    exit()


# calculate p_fix for small or large s, which we will use
# to calculate the rate of beneficial mutations

pfix = 0
if (s >= 0.1):
    pfix = math.exp(-(1+s))
    lim = 0
    while(lim < 100):
       pfix = math.exp((1+s)*(pfix-1))
       lim +=1
    pfix = 1-pfix
else:
    pfix = (1-math.exp(-2*s))/(1-math.exp(-2*alpha))

nu = 2*lam/pfix

# Calculate the simulated theta, which is not equal to
# theta at the neutral locus.  See SFS_CODE's manual for
# detailed explanation

theta_sim = (theta_des*L_mid + nu*2*L_flank)/(L_mid + 2*L_flank)
theta_sim_ratio = (theta_des*L_mid)/(nu*L_flank)

# recombination file, which sets the neutral locus to 
# be non-recombining.  This option can be dropped or 
# altered if a recombining neutral locus is desired

recombFile = os.path.join('recomb.long.'+str(int(L_flank))+'.'+str(int(L_mid))+'.txt')

middist = math.ceil(L_flank+L_mid)
finaldist = math.ceil(2*L_flank+L_mid)

try:
    os.stat(recombFile)
except:
    rfile = open(recombFile, 'w')
    rfile.write('3\n')
    rfile.write(str(int(math.ceil(L_flank))))
    rfile.write(' 0.5\n')
    rfile.write(str(int(middist)))
    rfile.write(' 0.50000000001\n')
    rfile.write(str(int(finaldist)))
    rfile.write(' 1.0\n')
    rfile.close()

sfs_code_arg = ['sfs_code'];
sfs_code_arg.append('1')
sfs_code_arg.append('10')
sfs_code_arg.append('-A')
sfs_code_arg.append('-t')
sfs_code_arg.append(str(theta_sim))
sfs_code_arg.append('-Z')
sfs_code_arg.append('-r')
sfs_code_arg.append('F')
sfs_code_arg.append(recombFile)
sfs_code_arg.append(str(rho))
sfs_code_arg.append('-N')
sfs_code_arg.append(str(N))
sfs_code_arg.append('-n')
sfs_code_arg.append('10')
sfs_code_arg.append('-L')
sfs_code_arg.append('3')
sfs_code_arg.append(str(L_flank))
sfs_code_arg.append(str(L_mid))
sfs_code_arg.append(str(L_flank))
sfs_code_arg.append('-a')
sfs_code_arg.append('N') 
sfs_code_arg.append('R')
sfs_code_arg.append('-v')
sfs_code_arg.append('L')
sfs_code_arg.append('A') 
sfs_code_arg.append('1')
sfs_code_arg.append('-v')
sfs_code_arg.append('L')
sfs_code_arg.append('1')
sfs_code_arg.append(str(theta_sim_ratio))
sfs_code_arg.append('-W')
sfs_code_arg.append('L')
sfs_code_arg.append('0') 
sfs_code_arg.append('1')
sfs_code_arg.append(str(alpha))
sfs_code_arg.append('1')
sfs_code_arg.append('0')
sfs_code_arg.append('-W')
sfs_code_arg.append('L') 
sfs_code_arg.append('2') 
sfs_code_arg.append('1') 
sfs_code_arg.append(str(alpha))
sfs_code_arg.append('1')
sfs_code_arg.append('0')

out_file = 'alg2_out.txt'

# random seed

rand_int = int(math.floor(100000*random.random()))

sfs_code_arg.append("-s")
sfs_code_arg.append(str(rand_int))

sfs_code_arg.append("-o")
sfs_code_arg.append(out_file)
	

command = ""
for item in sfs_code_arg:
    command+=item+" "

print command

