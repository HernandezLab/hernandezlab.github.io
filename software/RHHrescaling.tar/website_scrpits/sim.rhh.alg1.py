#!/usr/bin/python

import sys
import time
import math
import random
import os
from os.path import exists

# check input

if len(sys.argv) < 2:
    print 'usage: python' , sys.argv[0], '<argument>'
    print 'arguments: '
    print '--return_params'
    print '--build_sfs_code' 
    exit()

# out_file name

out_file = 'alg_1_out.txt'

# parameter values

alpha = 5*10**3         # the population scaled selection strength, which remains fixed
N0 = 5*10**3            # the population size in the model population
r0 = (5.*10**-8)        # the recombination rate per base pair per generation per chromosome
lam0 = (1.*10**-10)     # the rate of positively selected substitutions per generation

L0 = 10**6              # the length of the flanking sequence in the model population. 
                        # Although L0 can be whatever the user desires, to include all
                        # possible impactful sites it should be ~s0/r0 base pairs.
                        # Note: this guideline does not work when s0 is large.  See
                        # the paper for further guidelines

N = 200
theta_des = 0.002       # theta at the neutral locus
L_mid = 1000.0          # length of the neutral locus in base pairs
L_flank = 10**5         # the length of the flanking sequence (L1 in the paper)
s = (alpha ) / (2.0*N)  # the value of s (selection coefficient) in the simulated population

# a is dummy variable that computes the ratio of s/(rL) in the 
# population of size N0. We conserve this ratio under rescaling

a =  (alpha/(2.*N0))/(r0*L0)

r = s/(a*L_flank)
lam = lam0*r/r0
rho = r*4*N

if(sys.argv[1] == '--return_params'):
    print'N: ', N 
    print'L: ', L_flank 
    print'alpha: ', alpha 
    print'rho: ', rho 
    print'lambda: ', lam 
    exit()

# here we calculate the probability of fixation, wich we will 
# use to calculate the rate of beneficial mutations in the simulation

pfix = 0
if (s >= 0.1):
    pfix = math.exp(-(1+s))
    lim = 0
    while(lim < 100):
       pfix = math.exp((1+s)*(pfix-1))
       lim +=1
    pfix = 1-pfix
else:
    pfix = (1-math.exp(-2*s))/(1-math.exp(-2*alpha))

nu = 2*lam/pfix

# need to solve for simulation theta, which is not the same
# as theta at the neutral locus.  See SFS_CODE manual for
# more description of this calculation

theta_sim = (theta_des*L_mid + nu*2*L_flank)/(L_mid + 2*L_flank)
theta_sim_ratio = (theta_des*L_mid)/(nu*L_flank)

# build recombination file for sfs_code. This explicitly sets the
# neutral locus to be non-recombining.  This option can be removed or 
# altered to allow the neutral locus to recombine at some desired rate

recombFile = os.path.join('recomb.'+str(int(L_flank))+'.'+str(int(L_mid))+'.txt')

middist = math.ceil(L_flank+L_mid)
finaldist = math.ceil(2*L_flank+L_mid)

try:
    os.stat(recombFile)
except:
    rfile = open(recombFile, 'w')
    rfile.write('3\n')
    rfile.write(str(int(math.ceil(L_flank))))
    rfile.write(' 0.5\n')
    rfile.write(str(int(middist)))
    rfile.write(' 0.50000000001\n')
    rfile.write(str(int(finaldist)))
    rfile.write(' 1.0\n')
    rfile.close()

# yes, the following could be accomplished in one step
# it is laid out vertically to be easier on the eyes

sfs_code_arg = ['sfs_code'];
sfs_code_arg.append('1')
sfs_code_arg.append('10')
sfs_code_arg.append('-A')
sfs_code_arg.append('-t')
sfs_code_arg.append(str(theta_sim))
sfs_code_arg.append('-Z')
sfs_code_arg.append('-r')
sfs_code_arg.append('F')
sfs_code_arg.append(recombFile)
sfs_code_arg.append(str(rho))
sfs_code_arg.append('-N')
sfs_code_arg.append(str(N))
sfs_code_arg.append('-n')
sfs_code_arg.append('10')
sfs_code_arg.append('-L')
sfs_code_arg.append('3')
sfs_code_arg.append(str(L_flank))
sfs_code_arg.append(str(L_mid))
sfs_code_arg.append(str(L_flank))
sfs_code_arg.append('-a')
sfs_code_arg.append('N') 
sfs_code_arg.append('R')
sfs_code_arg.append('-v')
sfs_code_arg.append('L')
sfs_code_arg.append('A') 
sfs_code_arg.append('1')
sfs_code_arg.append('-v')
sfs_code_arg.append('L')
sfs_code_arg.append('1')
sfs_code_arg.append(str(theta_sim_ratio))
sfs_code_arg.append('-W')
sfs_code_arg.append('L')
sfs_code_arg.append('0') 
sfs_code_arg.append('1')
sfs_code_arg.append(str(alpha))
sfs_code_arg.append('1')
sfs_code_arg.append('0')
sfs_code_arg.append('-W')
sfs_code_arg.append('L') 
sfs_code_arg.append('2') 
sfs_code_arg.append('1') 
sfs_code_arg.append(str(alpha))
sfs_code_arg.append('1')
sfs_code_arg.append('0')

# make sure error/out directory exists
# random seed

rand_int = int(math.floor(100000*random.random()))
	
sfs_code_arg.append("-s")
sfs_code_arg.append(str(rand_int))

sfs_code_arg.append("-o")
sfs_code_arg.append(out_file)

command = ""
for item in sfs_code_arg:
    command+=item+" "

print command

