There are a few files that run the correction in R.  You can adapt your data to the following format, or perhaps just take the substitution rates from the file TransProb_context.R.  Again, let me know if you have any questions.

There are two R files you will need that are attached and a single input data set (an example file is attached as well).  The R script sfs_correct.r calls this input file by name, so the script must be edited if you are going to run it on a different data set (the location is indicated in the script).

The input data file has the site-frequency spectrum for the set of all context-dependent mutation categories (there are 256 categories, so this file has 256 lines).  In this file, I also include the number of fixed differences.  This is not the total number of fixed differences.  I had data from 30 chromosomes, but there was missing data so I took the expected site-frequency spectrum in a subsample of 16 chromosomes (some sites would look fixed in the subsample, but were polymorphic in the original sample).

For ease in looping, I have assigned each nucleotide a number between 0-3 as follows:

C = 0
G = 1
T = 2
A = 3

The rows in the file are then of the form:

WXY -> WZY

Where W, X, Y, and Z are the nucleotides using the above ordering, and the entries loop in the following order:  Z, Y, X, W. Specifically, the lines correspond to the following trinucleotide mutation categories:

1:  CCC->CCC (all zeros, included for simplicity)
2:  CCC->CGC
3:  CCC->CTC
4:  CCC->CAC
5:  CCG->CCG
6:  CCG->CGG
7:  CCG->CTG
8:  CCG->CAG
9:  CCT->CCT
10:  CCT->CGT
...
255:  AAA->ATA
256:  AAA->AAA

On each line, there is a site-frequency spectrum for the corresponding mutations.  This method does not handle missing data, so I have sub-sampled my data down to a consistent sample of size 16 chromosomes for all entries (hence the decimal entries).

The program will then create 3 files.  *_CORmat.txt is a file with the same form as the input data file, but with corrected cell entries, *_CORsfs.txt has the corrected site-frequency spectrum, and *_sfs.txt has the site-frequency spectrum based on your input data.
