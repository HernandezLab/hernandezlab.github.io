library(msm); #need to use functions in this library

#get rate and frequency matrix from another file
source("TransProb_context.R")

tau <- 0.0102;  #divergence rate between species
P <- MatrixExp(Q*tau); #exponentiate the rate matrix for trans. prob.

filename = 'mutClassSFS';  #don't include suffix .txt

DATA=read.table(paste(filename,".txt",sep="")); #read data table
SS = length(DATA[1,]); #sample size
N=matrix(0,nr=256,nc=SS); #observed data
R=matrix(0,nr=256,nc=SS); #corrected data

rowNum=0;
SNPs = 0;

N = DATA;
R[,SS] = N[,SS];
SNPs = sum(sum(DATA));
sum(sum(N))

#loop over all mutation categories and perform correction
for(i in 0:3){
  for(j in 0:3){
    for(k in 0:3){ #from trinuc. [ijk]
      for(m in 0:3){ #to trinuc. [imk]
        if(m!=j){
          u=16*i+4*j+k+1;
          x=16*i+4*m+k+1;
          fux=F[u]*P[u,u]/(F[u]*P[u,u]+F[x]*P[x,u]);
          fxu=F[x]*P[x,x]/(F[x]*P[x,x]+F[u]*P[u,x]);
          for(h in 1:(SS/2)){
            tmp=(fxu*N[4*(u-1)+m+1,h]-(1-fxu)*N[4*(x-1)+j+1,SS-h])/(fux+fxu-1);
            if(tmp>N[4*(u-1)+m+1,h]+N[4*(x-1)+j+1,SS-h]){
              ;#do not let entries go negative, assign all to one group
              R[4*(u-1)+m+1,h]=N[4*(u-1)+m+1,h]+N[4*(x-1)+j+1,SS-h];
              R[4*(x-1)+j+1,SS-h]=0;
              R[4*(x-1)+j+1,SS] = R[4*(x-1)+j+1,SS] + N[4*(x-1)+j+1,SS-h];
            }
            else{
              if(tmp<0){
                ;#do not let entries go negative, assign all to one group
                R[4*(u-1)+m+1,h]=0;
                R[4*(x-1)+j+1,SS-h]=N[4*(u-1)+m+1,h]+N[4*(x-1)+j+1,SS-h];
                R[4*(u-1)+m+1,SS] = R[4*(u-1)+m+1,SS] + N[4*(u-1)+m+1,h];
              }
              else{
                R[4*(u-1)+m+1,h]=tmp;
                R[4*(x-1)+j+1,SS-h]=N[4*(u-1)+m+1,h]+N[4*(x-1)+j+1,SS-h]-tmp;

                if(((N[4*(u-1)+m+1,h]-R[4*(u-1)+m+1,h]) - (R[4*(x-1)+j+1,SS-h]-N[4*(x-1)+j+1,SS-h])) > 1e-5){
                  cat("N[",4*(x-1)+j+1,",",SS-h,"]=",N[4*(x-1)+j+1,SS-h],"\n");
                  cat("R[",4*(x-1)+j+1,",",SS-h,"]=",R[4*(x-1)+j+1,SS-h],"\n");
                  cat("N[",4*(u-1)+m+1,",",h,"]=",N[4*(u-1)+m+1,h],"\n");
                  cat("R[",4*(u-1)+m+1,",",h,"]=",R[4*(u-1)+m+1,h],"\n");
                  cat("d1=",N[4*(u-1)+m+1,h]-R[4*(u-1)+m+1,h]," d2=",R[4*(x-1)+j+1,SS-h]-N[4*(x-1)+j+1,SS-h],"\n");
                }
              }
            }
          }
        }
      }
    }
  }
}



sfs_unc=array(0,SS);
sfs_cor=array(0,SS);

for(i in 1:SS){
  for(j in 1:256){
    if(R[j,i]<1e-5){
      R[j,i]=0;
    }
    sfs_cor[i]=sfs_cor[i]+R[j,i];
    sfs_unc[i]=sfs_unc[i]+N[j,i];
  }
}

#print file with corrected cell entries
fileOUT = paste(filename,'_CORmat.txt',sep="");
cat("",file=fileOUT);
for(i in 0:3){
  for(j in 0:3){
    for(k in 0:3){
      for(m in 0:3){
        cat(i,j,k," ",m," ",file=fileOUT,append=TRUE);
        for(h in 1:SS){
          cat(R[64*i+16*j+4*k+m+1,h]," ",file=fileOUT,append=TRUE);
        }
        cat("\n",file=fileOUT,append=TRUE);
      }
    }
  }
}

#print file with corrected sfs
fileOUT = paste(filename,'_CORsfs.txt', sep="");
cat("",file=fileOUT);
for(i in 1:SS){
  cat(format(sfs_cor[i],nsmall=3)," ",file=fileOUT,append=TRUE);
}
cat("\n",file=fileOUT,append=TRUE);

#print file with original sfs
fileOUT = paste(filename,'_sfs.txt', sep="");
cat("",file=fileOUT);
for(i in 1:SS){
  cat(sfs_unc[i]," ",file=fileOUT,append=TRUE);
}
cat("\n",file=fileOUT,append=TRUE);



